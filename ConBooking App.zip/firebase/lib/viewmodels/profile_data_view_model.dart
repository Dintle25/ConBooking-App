/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Profile data view model 
 */

// Import necessary packages for file handling and state management
import 'dart:io';
import 'package:flutter/material.dart';

// ViewModel class for managing profile data
class ProfileDataViewModel with ChangeNotifier {
  File? image; // Stores the user's profile image (optional)

  // Updates the profile with a new image
  void updateProfile({File? newImage}) {
    if (newImage != null) image = newImage; // Assigns new image if provided
    notifyListeners(); // Notifies listeners about the change in data
  }
}