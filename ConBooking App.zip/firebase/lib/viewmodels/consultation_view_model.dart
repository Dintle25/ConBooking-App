/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Consultation view model
 */

// Import required dependencies
import 'package:firebase/models/consultation.dart'; // Consultation model
import 'package:firebase/services/auth_service.dart'; // Authentication service
import 'package:firebase/views/Consultation_Form.dart'; // Consultation form widget
import 'package:flutter/material.dart'; // Flutter UI components
import 'package:provider/provider.dart'; // State management

// ViewModel class for managing consultation data
class ConsultationViewModel with ChangeNotifier {
  
  // Initializes an empty Consultation object as the model
  Consultation model = Consultation(
    id: '',
    date: '',
    time: '',
    description: '',
    topic: '',
    studId: '',
    lecture: '',
  );

  // Getters to access individual fields of the model
  String get id => model.id;
  String get date => model.date;
  String get time => model.time;
  String get description => model.description;
  String get topic => model.topic;
  String get lecture => model.lecture;

  // Displays a dialog to add a new consultation
  void showAddConsultationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add New Consultation'), // Dialog title
        content: ConsultationForm(
          // Callback function triggered upon submission
          onSubmit: (lecturer, date, time, topic, description) async {
            try {
              await Provider.of<AuthService>(context, listen: false).addConsultation(
                lecture: lecturer,
                date: date,
                time: time,
                description: description,
                topic: topic,
              );
              Navigator.pop(context); // Close the dialog after adding the consultation
            } catch (e) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Error adding Consultation: $e')),
              ); // Show error message if addition fails
            }
          },
        ),
      ),
    );
  }

  // Displays a dialog to edit an existing consultation
  void showEditConsultationDialog(BuildContext context, Consultation consultation) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Consultation'), // Dialog title
        content: ConsultationForm(
          // Initialize form fields with existing consultation data
          consultationId: consultation.id,
          initialLecture: consultation.lecture,
          initialDate: consultation.date,
          initialTime: consultation.time,
          initialTopic: consultation.topic,
          initialDescription: consultation.description,
          // Callback function triggered upon submission
          onSubmit: (lecture, date, time, topic, description) {
            Provider.of<AuthService>(context, listen: false).updateConsultation(
              consultation.id,
              lecture,
              date,
              time,
              topic,
              description,
            );
          },
        ),
      ),
    );
  }

  // Handles the deletion of a consultation
  Future<void> deleteConsultation(BuildContext context, String consultationId) async {
    // Show confirmation dialog before deleting
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Delete'), // Dialog title
        content: const Text('Are you sure you want to delete this consultation?'), // Warning message
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false), // Cancel deletion
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true), // Confirm deletion
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    // If user confirms deletion, proceed
    if (confirmed == true) {
      try {
        await Provider.of<AuthService>(context, listen: false).deleteConsultation(consultationId);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Consultation deleted successfully')),
        ); // Success message
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting consultation: $e')),
        ); // Error message if deletion fails
      }
    }
  }
}
