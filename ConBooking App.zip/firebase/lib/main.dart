/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Main
 */

import 'package:firebase/routes/app_router.dart'; // Import routing manager
import 'package:firebase/services/consultation_view_model.dart'; // Import consultation view model
import 'package:firebase/viewmodels/profile_data_view_model.dart'; // Import profile data view model
import 'package:flutter/foundation.dart'; // Import Flutter foundation library
import 'package:flutter/material.dart'; // Import material UI components
import 'package:firebase_core/firebase_core.dart'; // Import Firebase core functionality
import 'package:provider/provider.dart'; // Import Provider for state management
import 'services/auth_service.dart'; // Import authentication service

void main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Ensure Flutter framework is initialized

  // Initialize Firebase based on platform (Web or Mobile)
  if (kIsWeb) {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: "AIzaSyA6N3TihRTEsxBqZGHtCMEGtUTdxDJ4eO4", // Firebase API Key
        authDomain: "fir-38fe2.firebaseapp.com", // Firebase authentication domain
        projectId: "fir-38fe2", // Firebase project ID
        storageBucket: "fir-38fe2.firebasestorage.app", // Firebase storage bucket
        messagingSenderId: "701509524143", // Firebase messaging sender ID
        appId: "1:701509524143:web:1e5b60cf2a8942a949925a", // Firebase application ID
        measurementId: "G-S1XTCV7L5P", // Firebase measurement ID
      ),
    );
  } else {
    await Firebase.initializeApp(); // Initialize Firebase for non-web platforms
  }

  // Run the application with multiple state providers
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()), // Provides authentication state
        ChangeNotifierProvider(create: (_) => ConsultationViewModel()), // Manages consultation data
        ChangeNotifierProvider(create: (_) => ProfileDataViewModel()), // Handles profile data
      ],
      child: const MyApp(), // Load the main app widget
    ),
  );
}

// Main application widget
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Consultation Management App', // Set app title
      theme: ThemeData(
        primarySwatch: Colors.blue, // Define primary color scheme
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.pinkAccent), // Set seed color for themes
        fontFamily: 'LibreFranklin', // Set global font style

        // AppBar Theme - Defines global AppBar design
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.pinkAccent, // Set AppBar background color
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(30), // Apply curved shape to AppBar bottom
            ),
          ),
          titleTextStyle: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            fontFamily: 'LibreFranklin',
            color: Colors.white, // Set AppBar title text color
          ),
        ),

        // Floating Action Button Theme
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          backgroundColor: Colors.pinkAccent, // Set FAB background color
          foregroundColor: Colors.white, // Set FAB text/icon color
        ),

        // Text Button Theme
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            textStyle: TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: 16,
              fontFamily: 'LibreFranklin',
            ),
          ),
        ),

        // Elevated Button Theme - Defines global button styles
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.pinkAccent, // Set button background color
            foregroundColor: Colors.white, // Set button text color
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12), // Apply rounded corners
            ),
            padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20), // Set button padding
          ),
        ),
      ),

      debugShowCheckedModeBanner: false, // Hide debug banner
      initialRoute: RouteManager.loginPage, // Set initial page to login screen
      onGenerateRoute: RouteManager.generateRoute, // Handle app navigation
    );
  }
}
