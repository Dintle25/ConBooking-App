/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Route Manager 
 */


// Import necessary dependencies for authentication and views
import 'package:firebase/auth/admin.dart';
import 'package:firebase/auth/auth_page.dart';
import 'package:firebase/views/admin_consultations.dart';
import 'package:firebase/views/profile_screen.dart';
import 'package:firebase/views/student_dashboard.dart';
// import 'package:firebase/views/home_page.dart'; // (Unused import, can be removed)
import 'package:flutter/material.dart';

// Manages named routes for navigation in the application
class RouteManager {
  // Route constants for easy reference
  static const String loginPage = '/'; // Default route (Login)
  static const String registrationPage = '/register'; // Registration page
  static const String mainPage = '/main'; // Main student dashboard
  static const String profilePage = '/profilePage'; // Profile page
  static const String adminPage = '/adminPage'; // Admin consultations
  static const String adminLoginPage = '/adminLoginPage'; // Admin login page
  static const String adminLogin = '/adminLogin'; // Admin login route
  static const String adminRegister = '/adminRegister'; // Admin registration route

  // Generates route based on the requested route name
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case loginPage:
        return MaterialPageRoute(builder: (_) => const AuthPage(isLogin: true)); // Login Page

      case registrationPage:
        return MaterialPageRoute(builder: (_) => const AuthPage(isLogin: false)); // Registration Page

      case mainPage:
        return MaterialPageRoute(builder: (_) => StudentDashboard()); // Student Dashboard

      case profilePage:
        return MaterialPageRoute(builder: (_) => ProfileScreen()); // Profile Screen

      case adminPage:
        return MaterialPageRoute(builder: (_) => AdminConsultations()); // Admin Consultation Page

      case adminLogin:
        return MaterialPageRoute(builder: (_) => AdminAuthPage(isLogin: true)); // Admin Login Page

      case adminRegister:
        return MaterialPageRoute(builder: (_) => AdminAuthPage(isLogin: false)); // Admin Registration Page

      default:
        // Handles undefined routes by showing an error message
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(child: Text('No route for ${settings.name}')), // Error message for unknown routes
          ),
        );
    }
  }
}