/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Admin Dashboard
 */


// Import necessary dependencies for Firestore database access, authentication, and UI components
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase/models/consultation.dart';
import 'package:firebase/services/auth_service.dart';
import 'package:firebase/services/consultation_view_model.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// Admin Consultations Page (Displays a list of consultation records)
class AdminConsultations extends StatefulWidget {
  const AdminConsultations({super.key});

  @override
  State<AdminConsultations> createState() => _AdminConsultationsState();
}

class _AdminConsultationsState extends State<AdminConsultations> {
  @override
  Widget build(BuildContext context) {
    return Consumer<ConsultationViewModel>(
      builder: (context, filterProvider, child) {
        return Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false, // Removes back button
            title: const Text('All Consultations'), // Page title
            actions: [
              // Logout button to sign out an admin
              IconButton(
                icon: const Icon(Icons.logout, color: Colors.white),
                onPressed: () async {
                  await FirebaseAuth.instance.signOut();
                  Navigator.pushReplacementNamed(context, '/adminLogin'); // Redirect to admin login
                },
              ),
            ],
          ),
          body: Column(
            children: [
              const SizedBox(height: 10),
              
              // Search field for filtering consultations by Student ID
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  decoration: InputDecoration(
                    label: const Text('Search by Student ID'),
                    hintText: 'Enter Student ID in full',
                    prefixIcon: const Icon(Icons.search), // Search icon
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                    labelStyle: const TextStyle(fontWeight: FontWeight.w900),
                    hintStyle: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                  onChanged: (value) {
                    filterProvider.setSearchStudentId(value.trim()); // Filters results by Student ID
                  },
                ),
              ),

              // Date range filters for narrowing consultations by time period
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  const Text("Filter : ", style: TextStyle(fontWeight: FontWeight.w900)),
                  
                  // Start Date filter
                  TextButton(
                    onPressed: () async {
                      DateTime? picked = await showDatePicker(
                        context: context,
                        initialDate: filterProvider.startDate ?? DateTime.now(),
                        firstDate: DateTime.now(),
                        lastDate: DateTime(2050),
                      );
                      if (picked != null) {
                        filterProvider.setStartDate(picked); // Stores selected start date
                      }
                    },
                    child: Text(
                      filterProvider.startDate == null
                          ? 'Start Date'
                          : 'Start: ${filterProvider.formatDate(filterProvider.startDate!)}',
                    ),
                  ),

                  // End Date filter
                  TextButton(
                    onPressed: () async {
                      DateTime? picked = await showDatePicker(
                        context: context,
                        initialDate: filterProvider.endDate ?? DateTime.now(),
                        firstDate: DateTime.now(),
                        lastDate: DateTime(2050),
                      );
                      if (picked != null) {
                        filterProvider.setEndDate(picked); // Stores selected end date
                      }
                    },
                    child: Text(
                      filterProvider.endDate == null
                          ? 'End Date'
                          : 'End: ${filterProvider.formatDate(filterProvider.endDate!)}',
                    ),
                  ),
                ],
              ),

              // Display filtered consultations from Firestore
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: _buildFilteredStream(filterProvider), // Fetch filtered data from Firestore
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return const Center(child: Text('Enter Student ID in full')); // Display error message
                    }
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator()); // Show loading state
                    }

                    final consultations = snapshot.data!.docs; // Extract consultations from snapshot

                    if (consultations.isEmpty) {
                      return const Center(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('Hey, no worries!', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
                            Text("Can you try entering the student ID in full, then we will take it from there?", style: TextStyle(fontWeight: FontWeight.w900)),
                          ],
                        ),
                      );
                    }

                    // List of consultations
                    return ListView.builder(
                      itemCount: consultations.length,
                      itemBuilder: (context, index) {
                        final doc = consultations[index];
                        final data = doc.data() as Map<String, dynamic>;
                        final consultation = Consultation.fromFirestore(doc);

                        return Card(
                          elevation: 0.5,
                          child: ListTile(
                            title: Text('Student ID: ${data['studentId']}', style: const TextStyle(fontWeight: FontWeight.w900)),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Lecturer: ${data['lecture']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                                Text('Date and Time: ${data['date']} - ${data['time']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                                Text('Topic: ${data['topic']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                              ],
                            ),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete, color: Colors.pink),
                              onPressed: () => _deleteConsultation(context, doc.id), // Delete consultation action
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
              const SizedBox(height: 7),
            ],
          ),
        );
      },
    );
  }

  // Build Firestore Query with filters for Student ID and Date Range
  Stream<QuerySnapshot> _buildFilteredStream(ConsultationViewModel filterProvider) {
    Query query = FirebaseFirestore.instance.collection('consultations'); // Fetch consultations collection

    if (filterProvider.searchStudentId.isNotEmpty) {
      query = query.where('studentId', isEqualTo: filterProvider.searchStudentId); // Apply student ID filter
    }

    if (filterProvider.startDate != null) {
      query = query.where(
        'date',
        isGreaterThanOrEqualTo: filterProvider.formatDate(filterProvider.startDate!),
      ); // Apply start date filter
    }

    if (filterProvider.endDate != null) {
      query = query.where(
        'date',
        isLessThanOrEqualTo: filterProvider.formatDate(filterProvider.endDate!),
      ); // Apply end date filter
    }

    return query.snapshots(); // Returns filtered results in real-time
  }

  // Delete consultation from Firestore
  Future<void> _deleteConsultation(BuildContext context, String consultationId) async {
    // Display confirmation dialog before deleting
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Delete'), // Dialog title
        content: const Text('Are you sure you want to delete this consultation?'), // Warning message
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false), // Cancel deletion
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true), // Confirm deletion
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        await Provider.of<AuthService>(context, listen: false).deleteConsultation(consultationId); // Delete consultation from Firestore
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Consultation deleted successfully'))); // Success message
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error deleting consultation: $e'))); // Error message
      }
    }
  }
}
