/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Consultation Form 
 */


// Import required dependencies
import 'package:flutter/material.dart'; // UI components
import 'package:intl/intl.dart'; // Date and time formatting

// Stateful Widget for handling consultation form input
class ConsultationForm extends StatefulWidget {
  final String? consultationId; // Unique consultation ID (optional)
  final String? initialLecture; // Initial selected lecturer (optional)
  final String? initialDate; // Initial selected date (optional)
  final String? initialTime; // Initial selected time (optional)
  final String? initialTopic; // Initial topic text (optional)
  final String? initialDescription; // Initial description text (optional)

  // Callback function triggered when the user submits the form
  final Function(
    String lecture,
    String date,
    String time,
    String topic,
    String description,
  ) onSubmit;

  // Constructor to initialize the consultation form
  const ConsultationForm({
    super.key,
    this.consultationId,
    this.initialLecture,
    this.initialDate,
    this.initialTime,
    this.initialTopic,
    this.initialDescription,
    required this.onSubmit,
  });

  @override
  State<ConsultationForm> createState() => _ConsultationFormState();
}

class _ConsultationFormState extends State<ConsultationForm> {
  final _formKey = GlobalKey<FormState>(); // Key for form validation
  final _topicController = TextEditingController(); // Controller for topic input
  final _descriptionController = TextEditingController(); // Controller for description input
  final _dateController = TextEditingController(); // Controller for date input
  final _timeController = TextEditingController(); // Controller for time input

  String? _selectedLecture; // Stores selected lecturer from dropdown

  // List of available lecturers
  final List<String> _lectures = ['E. Siase', 'M. Thuto', 'R. Sekupu'].toSet().toList();

  @override
  void initState() {
    super.initState();
    
    // Initialize form fields with existing consultation data
    if (widget.initialLecture != null && _lectures.contains(widget.initialLecture!.trim())) {
      _selectedLecture = widget.initialLecture!.trim();
    } else {
      _selectedLecture = null;
    }
    
    if (widget.initialDate != null) _dateController.text = widget.initialDate!;
    if (widget.initialTime != null) _timeController.text = widget.initialTime!;
    if (widget.initialTopic != null) _topicController.text = widget.initialTopic!;
    if (widget.initialDescription != null) _descriptionController.text = widget.initialDescription!;
  }

  // Method to pick a date using the Date Picker
  Future<void> _pickDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2050),
    );
    if (picked != null) {
      _dateController.text = DateFormat('yyyy-MM-dd').format(picked); // Format date
    }
  }

  // Method to pick a time using the Time Picker
  Future<void> _pickTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      final now = DateTime.now();
      final dt = DateTime(now.year, now.month, now.day, picked.hour, picked.minute);
      _timeController.text = DateFormat('HH:mm').format(dt); // Format time
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey, // Assign form key for validation
      child: Column(
        mainAxisSize: MainAxisSize.min, // Minimize column size
        children: [
          // Dropdown list for selecting a lecturer
          DropdownButtonFormField<String>(
            value: _selectedLecture,
            decoration: InputDecoration(
              labelText: 'Lecture',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              labelStyle: const TextStyle(fontWeight: FontWeight.w900),
              hintStyle: const TextStyle(fontWeight: FontWeight.w900),
            ),
            items: _lectures.map((lecture) {
              return DropdownMenuItem(
                value: lecture,
                child: Text(lecture),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                _selectedLecture = value;
              });
            },
            validator: (value) => value == null || value.isEmpty ? 'Please select a lecture' : null,
          ),
          const SizedBox(height: 5),

          // Date Picker input field
          TextFormField(
            controller: _dateController,
            readOnly: true,
            decoration: InputDecoration(
              labelText: 'Date',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              labelStyle: const TextStyle(fontWeight: FontWeight.w900),
              hintStyle: const TextStyle(fontWeight: FontWeight.w900),
            ),
            onTap: _pickDate, // Opens date picker
            validator: (value) => value!.isEmpty ? 'Required' : null,
          ),
          const SizedBox(height: 5),

          // Time Picker input field
          TextFormField(
            controller: _timeController,
            readOnly: true,
            decoration: InputDecoration(
              labelText: 'Time',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              labelStyle: const TextStyle(fontWeight: FontWeight.w900),
              hintStyle: const TextStyle(fontWeight: FontWeight.w900),
            ),
            onTap: _pickTime, // Opens time picker
            validator: (value) => value!.isEmpty ? 'Required' : null,
          ),
          const SizedBox(height: 5),

          // Topic input field
          TextFormField(
            controller: _topicController,
            decoration: InputDecoration(
              labelText: 'Topic',
              hintText: 'Enter the topic',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              labelStyle: const TextStyle(fontWeight: FontWeight.w900),
              hintStyle: const TextStyle(fontWeight: FontWeight.w900),
            ),
            validator: (value) {
              if (value!.isEmpty) {
                return 'Required';
              } else if (value.length < 20) {
                return 'Topic must be at least 20 characters';
              }
              return null; // Return null if valid
            },
          ),
          const SizedBox(height: 5),

          // Description input field
          TextFormField(
            controller: _descriptionController,
            decoration: InputDecoration(
              labelText: 'Description',
              hintText: 'Enter the description',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              labelStyle: const TextStyle(fontWeight: FontWeight.w900),
              hintStyle: const TextStyle(fontWeight: FontWeight.w900),
            ),
            validator: (value) => value!.isEmpty ? 'Required' : null,
          ),
          
          const SizedBox(height: 20),

          // Submit button (Adds or Updates a consultation)
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                widget.onSubmit(
                  _selectedLecture!,
                  _dateController.text.trim(),
                  _timeController.text.trim(),
                  _topicController.text.trim(),
                  _descriptionController.text.trim(),
                );
                Navigator.pop(context); // Close the dialog upon submission
              }
            },
            child: Text(
              widget.consultationId == null ? 'Add Consultation' : 'Update Consultation',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}