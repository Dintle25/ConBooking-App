/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Profile Screen 
 */

// Import necessary dependencies for authentication, Firestore, UI components, and image handling
import 'dart:io';
import 'package:firebase/models/student.dart'; // Student model
import 'package:firebase/routes/app_router.dart'; // Route manager
import 'package:firebase/services/auth_service.dart'; // Authentication service
import 'package:firebase/viewmodels/profile_data_view_model.dart'; // Profile ViewModel
import 'package:firebase/views/students_screen.dart'; // Student screen
import 'package:firebase_auth/firebase_auth.dart'; // Firebase authentication
import 'package:flutter/material.dart'; // UI components
import 'package:image_picker/image_picker.dart'; // Image picker for profile picture
import 'package:provider/provider.dart'; // State management

// Profile screen for displaying and updating student details
class ProfileScreen extends StatelessWidget {
  ProfileScreen({super.key});

  final ImagePicker _picker = ImagePicker(); // Image picker instance

  // Method to allow the user to pick a profile picture from their gallery
  Future<void> _pickImage(BuildContext context) async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      Provider.of<ProfileDataViewModel>(context, listen: false)
          .updateProfile(newImage: File(pickedFile.path)); // Updates profile picture
    }
  }

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context); // Provides authentication services

    return Consumer<ProfileDataViewModel>(
      builder: (context, picture, child) {
        return Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false, // Removes back button
            title: const Text(
              'Student Details',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          
          // Bottom navigation bar with home and profile buttons
          bottomNavigationBar: BottomAppBar(
            shape: const CircularNotchedRectangle(), // Rounded shape
            notchMargin: 8.0, // Margin space for floating action button
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                // Home icon button
                IconButton(
                  icon: const Icon(Icons.home),
                  onPressed: () {
                    Navigator.pushNamed(context, RouteManager.mainPage);
                  },
                ),
                // Profile icon button
                IconButton(
                  icon: const Icon(Icons.person),
                  onPressed: () {
                    Navigator.pushNamed(context, RouteManager.profilePage);
                  },
                ),
              ],
            ),
          ),

          // Main content area displaying student information
          body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: ListView(
              children: [
                Center(
                  child: FutureBuilder<Student?>(
                    future: authService.getStudentData(authService.currentUser!.uid), // Fetch student data
                    builder: (context, userSnapshot) {
                      if (userSnapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator()); // Loading indicator
                      } else if (userSnapshot.hasError) {
                        return Center(child: Text('Error: ${userSnapshot.error}')); // Error message
                      } else if (!userSnapshot.hasData) {
                        return const Center(child: Text('No student data available')); // No data message
                      }

                      final user = userSnapshot.data!; // Extract student data
                      final userId = FirebaseAuth.instance.currentUser!.uid; // Get current user ID

                      return Column(
                        children: [
                          // Profile picture section
                          GestureDetector(
                            onTap: () => _pickImage(context),
                            child: CircleAvatar(
                              radius: 50, // Profile picture size
                              backgroundImage: picture.image != null
                                  ? FileImage(picture.image!) // Display selected profile picture
                                  : const NetworkImage(
                                      'https://th.bing.com/th/id/OIP.jkywKMQLRDYYuMkiOJLSHAHaFj?w=244&h=183&c=7&r=0&o=5&pid=1.7',
                                    ), // Default profile picture
                              child: picture.image == null
                                  ? const Icon(Icons.camera_alt, size: 50, color: Colors.white) // Camera icon if no image
                                  : null,
                            ),
                          ),
                          const SizedBox(height: 10),

                          // Display student details
                          Text('First Name : ${user.firstName}', style: const TextStyle(fontWeight: FontWeight.w900)),
                          const SizedBox(height: 10),
                          Text('Surname : ${user.surname}', style: const TextStyle(fontWeight: FontWeight.w900)),
                          const SizedBox(height: 10),
                          Text('Phone Number : ${user.phoneNumber}', style: const TextStyle(fontWeight: FontWeight.w900)),
                          const SizedBox(height: 10),
                          Text('Student Number: ${user.studentId}', style: const TextStyle(fontWeight: FontWeight.w900)),
                          const SizedBox(height: 10),

                          // Button to open edit student dialog
                          ElevatedButton(
                            onPressed: () {
                              _showEditStudentDialog(context, user, userId);
                            },
                            child: const Text(
                              'Update information',
                              style: TextStyle(fontWeight: FontWeight.w900),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // Displays a dialog for editing student details
  void _showEditStudentDialog(BuildContext context, Student student, String docId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Student Details'),
        content: StudentForm(
          initialFirstName: student.firstName,
          initialPhoneNumber: student.phoneNumber,
          initialStudentId: student.studentId,
          initialSurname: student.surname,
          
          // Callback function triggered upon submission
          onSubmit: (firstName, surname, phoneNumber, studentId) {
            Provider.of<AuthService>(context, listen: false).updateStudent(
              docId,
              studentId,
              firstName,
              surname,
              phoneNumber,
            );
          },
        ),
      ),
    );
  }
}