/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Student Dashboard 
 */


import 'package:firebase/models/consultation.dart'; // Import consultation model
import 'package:firebase/models/student.dart'; // Import student model
import 'package:firebase/routes/app_router.dart'; // Import route manager
import 'package:firebase/views/Consultation_Form.dart'; // Import consultation form view
import 'package:firebase_auth/firebase_auth.dart'; // Import Firebase authentication
import 'package:flutter/material.dart'; // Import Flutter UI framework
import 'package:provider/provider.dart'; // Import Provider for state management
import '../services/auth_service.dart'; // Import authentication service

// StudentDashboard is a stateless widget that represents the home screen for students
class StudentDashboard extends StatelessWidget {
  const StudentDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(
      context,
    ); // Get authentication service

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // Remove back button
        title: const Text(
          'Home', // Title of the screen
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.logout,
              color: Colors.white,
            ), // Logout button
            onPressed: () async {
              await FirebaseAuth.instance.signOut(); // Sign out user
              Navigator.pushReplacementNamed(
                context,
                '/', // Redirect to login or home
              );
            },
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(), // Create a notch shape
        notchMargin: 8.0, // Space around the notch
        child: Row(
          mainAxisAlignment:
              MainAxisAlignment.spaceAround, // Spread buttons evenly
          children: [
            IconButton(
              icon: const Icon(Icons.home), // Home button
              onPressed: () {
                Navigator.pushNamed(
                  context,
                  RouteManager.mainPage,
                ); // Go to home
              },
            ),
            IconButton(
              icon: const Icon(Icons.person), // Profile button
              onPressed: () {
                Navigator.pushNamed(
                  context,
                  RouteManager.profilePage,
                ); // Go to profile
              },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed:
            () =>
                _showAddConsultationDialog(context), // Open consultation dialog
        child: const Icon(Icons.add), // Button to add consultation
      ),
      body: Center(
        child: FutureBuilder<Student?>(
          future: authService.getStudentData(
            authService.currentUser!.uid,
          ), // Get student data
          builder: (context, userSnapshot) {
            if (userSnapshot.connectionState == ConnectionState.waiting) {
              return const CircularProgressIndicator(); // Show loading indicator
            }
            if (userSnapshot.hasError) {
              return Text('Error: ${userSnapshot.error}'); // Show error message
            }
            if (!userSnapshot.hasData) {
              return const Text(
                'User not found',
              ); // Show message if no user found
            }

            final user = userSnapshot.data!; // Get user data
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(20.0), // Add spacing
                  child: Column(
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment:
                            MainAxisAlignment.center, // Center text
                        children: [
                          Text(
                            'Welcome, ', // Welcome message
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          Text(
                            user.firstName, // Display student’s first name
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 15), // Add spacing
                    ],
                  ),
                ),

                const SizedBox(height: 5), // Add spacing
                const Text(
                  'Your Consultations', // Heading for consultations section
                ),
                Expanded(
                  child: _buildConsultationsList(context),
                ), // Show list of consultations
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildConsultationsList(BuildContext context) {
    return Consumer<AuthService>(
      // Listen for authentication changes
      builder: (BuildContext context, AuthService value, Widget? child) {
        return StreamBuilder<List<Consultation>>(
          stream: value.getConsultations(), // Fetch list of consultations
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const CircularProgressIndicator(); // Show loading indicator
            }
            if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}'); // Show error message
            }
            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return Center(
                child: const Text('No consultations found.'),
              ); // Show message when no consultations exist
            }

            final consultations = snapshot.data!; // Extract consultations data
            final groupedConsultations = _groupConsultationsByDate(
              consultations,
            ); // Group consultations by date

            return ListView(
              children:
                  groupedConsultations.entries.map((entry) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          entry.key, // Display date
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        ...entry.value.map(
                          (consultation) => Card(
                            elevation: 0.5, // Add slight shadow for better UI
                            child: ListTile(
                              title: Text(
                                consultation.lecture, // Show consultation topic
                                style: TextStyle(fontWeight: FontWeight.w900),
                              ),
                              subtitle: Text(
                                consultation
                                    .topic, // Show consultation description
                                style: TextStyle(fontWeight: FontWeight.w900),
                              ),
                              leading: Icon(
                                consultation.status == false
                                    ? Icons.check_circle
                                    : Icons.hourglass_empty,
                                color:
                                    consultation.status
                                        ? Colors.green
                                        : Colors.orange, // Indicate status
                              ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.edit), // Edit button
                                    onPressed:
                                        () => _showEditConsultationDialog(
                                          context,
                                          consultation,
                                        ),
                                  ),
                                  IconButton(
                                    icon: const Icon(
                                      Icons.delete,
                                    ), // Delete button
                                    onPressed:
                                        () => _deleteConsultation(
                                          context,
                                          consultation.id,
                                        ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 7), // Add spacing
                      ],
                    );
                  }).toList(),
            );
          },
        );
      },
    );
  }

  // Function to group consultations by date
  Map<String, List<Consultation>> _groupConsultationsByDate(
    List<Consultation> consultations,
  ) {
    return {
      for (var consultation in consultations)
        consultation.date:
            consultations.where((c) => c.date == consultation.date).toList(),
    };
  }

  // Function to display form for adding consultations
  void _showAddConsultationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Add New Consultation'),
            content: ConsultationForm(
              onSubmit: (lecturer, date, time, topic, description) async {
                try {
                  await Provider.of<AuthService>(
                    context,
                    listen: false,
                  ).addConsultation(
                    lecture: lecturer,
                    date: date,
                    time: time,
                    description: description,
                    topic: topic,
                  );
                  Navigator.pop(context); // Close the dialog after adding
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error adding Consultation: $e')),
                  );
                }
              },
            ),
          ),
    );
  }

  // Function to edit consultation details
  void _showEditConsultationDialog(
    BuildContext context,
    Consultation consultation,
  ) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Edit Consultation'),
            content: ConsultationForm(
              consultationId: consultation.id,
              initialLecture: consultation.lecture,
              initialDate: consultation.date,
              initialTime: consultation.time,
              initialTopic: consultation.topic,
              initialDescription: consultation.description,
              onSubmit: (lecture, date, time, topic, description) {
                Provider.of<AuthService>(
                  context,
                  listen: false,
                ).updateConsultation(
                  consultation.id,
                  lecture,
                  date,
                  time,
                  topic,
                  description,
                );
              },
            ),
          ),
    );
  }

  // Function to delete consultation after confirmation
  Future<void> _deleteConsultation(
    BuildContext context,
    String consultationId,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Confirm Delete'),
            content: const Text(
              'Are you sure you want to delete this consultation?',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Delete'),
              ),
            ],
          ),
    );
    if (confirmed == true) {
      try {
        await Provider.of<AuthService>(
          context,
          listen: false,
        ).deleteConsultation(consultationId);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Consultation deleted successfully')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting consultation: $e')),
        );
      }
    }
  }
}
