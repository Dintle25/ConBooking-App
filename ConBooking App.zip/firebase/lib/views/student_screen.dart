/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Student Add or Update
 */


import 'package:flutter/material.dart';

// StudentForm allows users to add or edit student details
class StudentForm extends StatefulWidget {
  final String? studentId; // Student ID (if editing)
  final String? initialFirstName; // Initial first name (for editing)
  final String? initialSurname; // Initial surname (for editing)
  final String? initialPhoneNumber; // Initial phone number (for editing)
  final String? initialStudentId; // Initial student ID (for editing)
  final Function(String firstName, String surname, String phoneNumber, String studentId) onSubmit; // Function to handle form submission

  const StudentForm({
    super.key,
    this.studentId,
    this.initialFirstName,
    this.initialSurname,
    this.initialPhoneNumber,
    this.initialStudentId,
    required this.onSubmit,
  });

  @override
  State<StudentForm> createState() => _StudentFormState();
}

class _StudentFormState extends State<StudentForm> {
  final _formKey = GlobalKey<FormState>(); // Key to manage form state
  final _firstNameController = TextEditingController(); // Controller for first name input
  final _surnameController = TextEditingController(); // Controller for surname input
  final _phoneController = TextEditingController(); // Controller for phone number input
  final _studentIdController = TextEditingController(); // Controller for student ID input

  @override
  void initState() {
    super.initState();
    // Populate fields with existing values if editing
    if (widget.initialFirstName != null) _firstNameController.text = widget.initialFirstName!;
    if (widget.initialSurname != null) _surnameController.text = widget.initialSurname!;
    if (widget.initialPhoneNumber != null) _phoneController.text = widget.initialPhoneNumber!;
    if (widget.initialStudentId != null) _studentIdController.text = widget.initialStudentId!;
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey, // Assign form key for validation
      child: Column(
        children: [
          // First Name Input Field
          TextFormField(
            controller: _firstNameController,
            decoration: InputDecoration(
              labelText: 'First Name', // Label for the field
              hintText: 'Enter first name', // Hint text
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)), // Rounded border
              labelStyle: TextStyle(fontWeight: FontWeight.w900),
              hintStyle: TextStyle(fontWeight: FontWeight.w900),
            ),
            validator: (value) => value!.isEmpty ? 'Required' : null, // Validation check
          ),
          SizedBox(height: 5), // Spacing between fields

          // Surname Input Field
          TextFormField(
            controller: _surnameController,
            decoration: InputDecoration(
              labelText: 'Surname',
              hintText: 'Enter last name',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              labelStyle: TextStyle(fontWeight: FontWeight.w900),
              hintStyle: TextStyle(fontWeight: FontWeight.w900),
            ),
            validator: (value) => value!.isEmpty ? 'Required' : null,
          ),
          SizedBox(height: 5),

          // Phone Number Input Field
          TextFormField(
            controller: _phoneController,
            decoration: InputDecoration(
              labelText: 'Phone Number',
              hintText: 'Enter phone number',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              labelStyle: TextStyle(fontWeight: FontWeight.w900),
              hintStyle: TextStyle(fontWeight: FontWeight.w900),
            ),
            keyboardType: TextInputType.phone, // Set keyboard type for phone input
            validator: (value) => value!.isEmpty ? 'Required' : null,
          ),
          SizedBox(height: 5),

          // Student ID Input Field
          TextFormField(
            controller: _studentIdController,
            decoration: InputDecoration(
              labelText: 'Student ID',
              hintText: 'Enter Student ID',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              labelStyle: TextStyle(fontWeight: FontWeight.w900),
              hintStyle: TextStyle(fontWeight: FontWeight.w900),
            ),
            validator: (value) => value!.isEmpty ? 'Required' : null,
          ),
          SizedBox(height: 5),

          const SizedBox(height: 20), // Spacing before button

          // Submit Button (Add or Update Student)
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) { // Validate input fields
                widget.onSubmit(
                  _firstNameController.text.trim(),
                  _surnameController.text.trim(),
                  _phoneController.text.trim(),
                  _studentIdController.text.trim(),
                );
              }
            },
            child: Text(
              widget.studentId == null ? 'Add Student' : 'Update Student', // Change button text based on action
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}