/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Student Profile Details Update
 */

import 'package:firebase/services/auth_service.dart'; // Import authentication service
import 'package:flutter/material.dart'; // Import Flutter UI framework
import 'package:provider/provider.dart'; // Import Provider for state management

// StudentForm allows users to add or update student details
class StudentForm extends StatefulWidget {
  final String? initialFirstName; // Initial first name (if editing)
  final String? initialSurname; // Initial surname (if editing)
  final String? initialPhoneNumber; // Initial phone number (if editing)
  final String? initialStudentId; // Initial student ID (if editing)
  final Function(
    String firstName,
    String surname,
    String phone,
    String studentId,
  ) onSubmit; // Function to handle form submission

  const StudentForm({
    super.key,
    this.initialFirstName,
    this.initialSurname,
    this.initialPhoneNumber,
    this.initialStudentId,
    required this.onSubmit,
  });

  @override
  State<StudentForm> createState() => _StudentFormState();
}

class _StudentFormState extends State<StudentForm> {
  final _formKey = GlobalKey<FormState>(); // Key to manage form state

  // Controllers for input fields
  late final TextEditingController _firstNameController;
  late final TextEditingController _surnameController;
  late final TextEditingController _phoneNumberController;
  late final TextEditingController _studentIdController;

  @override
  void initState() {
    super.initState();
    // Populate fields with existing values if editing
    _firstNameController = TextEditingController(text: widget.initialFirstName ?? '');
    _surnameController = TextEditingController(text: widget.initialSurname ?? '');
    _phoneNumberController = TextEditingController(text: widget.initialPhoneNumber ?? '');
    _studentIdController = TextEditingController(text: widget.initialStudentId ?? '');
  }

  @override
  void dispose() {
    // Dispose controllers when widget is removed
    _firstNameController.dispose();
    _surnameController.dispose();
    _phoneNumberController.dispose();
    _studentIdController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey, // Assign form key for validation
      child: Column(
        mainAxisSize: MainAxisSize.min, // Ensure form doesn't take full screen height
        children: [
          // First Name Input Field
          TextFormField(
            controller: _firstNameController,
            decoration: InputDecoration(
              labelText: 'First Name', // Label for the field
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)), // Rounded border
              labelStyle: TextStyle(fontWeight: FontWeight.w900),
              hintStyle: TextStyle(fontWeight: FontWeight.w900),
            ),
          ),
          SizedBox(height: 10), // Spacing between fields

          // Surname Input Field
          TextFormField(
            controller: _surnameController,
            decoration: InputDecoration(
              labelText: 'Surname',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              labelStyle: TextStyle(fontWeight: FontWeight.w900),
              hintStyle: TextStyle(fontWeight: FontWeight.w900),
            ),
          ),
          SizedBox(height: 10),

          // Phone Number Input Field
          TextFormField(
            controller: _phoneNumberController,
            decoration: InputDecoration(
              labelText: 'Phone Number',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              labelStyle: TextStyle(fontWeight: FontWeight.w900),
              hintStyle: TextStyle(fontWeight: FontWeight.w900),
            ),
            keyboardType: TextInputType.phone, // Set keyboard type for phone input
          ),
          SizedBox(height: 10),

          // Student ID Input Field
          TextFormField(
            controller: _studentIdController,
            decoration: InputDecoration(
              labelText: 'Student Number',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              labelStyle: TextStyle(fontWeight: FontWeight.w900),
              hintStyle: TextStyle(fontWeight: FontWeight.w900),
            ),
          ),
          const SizedBox(height: 20),

          // Submit Button (Update Student)
          Consumer<AuthService>(
            builder: (context, viewModel, child) {
              return ElevatedButton(
                onPressed: () {
                  // Call the submission function when button is pressed
                  widget.onSubmit(
                    _firstNameController.text.trim(),
                    _surnameController.text.trim(),
                    _phoneNumberController.text.trim(),
                    _studentIdController.text.trim(),
                  );
                  Navigator.pop(context); // Close the form after submission
                },
                child: const Text('Update Student', style: TextStyle(fontWeight: FontWeight.w900)),
              );
            },
          ),
        ],
      ),
    );
  }
}
