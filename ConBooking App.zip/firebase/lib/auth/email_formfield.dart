/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Email form field
 */

// Import Flutter's material library for UI components
import 'package:flutter/material.dart';

// Defines a reusable email input field for forms
class EmailFormField extends StatelessWidget {
  final TextEditingController controller; // Controller to manage email input

  // Constructor requires a controller for handling user input
  const EmailFormField({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller, // Connects input field to the provided controller
      keyboardType: TextInputType.emailAddress, // Sets the keyboard type to email format

      // Defines the visual design of the input field
      decoration: InputDecoration(
        labelText: 'CUT Email', // Label shown above the field
        prefixIcon: const Icon(Icons.email), // Adds an email icon next to the input box
        hintText: 'Enter cut email', // Hint text inside the input field
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)), // Sets rounded border
        labelStyle: const TextStyle(fontWeight: FontWeight.w900), // Styles the label text
        hintStyle: const TextStyle(fontWeight: FontWeight.w900), // Styles the hint text
      ),

      // Validator ensures only CUT emails are accepted
      validator: (value) {
        if (value == null || value.isEmpty) return 'Email is required'; // Checks if field is empty
        if (!value.endsWith('@cut.ac.za')) return 'Only CUT emails allowed'; // Ensures email ends with "@cut.ac.za"
        return null; // Returns null if input is valid
      },
    );
  }
}
