/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : First name form field
 */



// Import Flutter's material library for UI components
import 'package:flutter/material.dart';

// Defines a reusable form field for entering the first name
class FirstNameFormField extends StatelessWidget {
  final TextEditingController controller; // Controller to manage text input

  // Constructor that requires a controller for handling user input
  const FirstNameFormField({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller, // Connects input field to the provided controller

      // Adds label, icon, hint text, and border styling
      decoration: InputDecoration(
        labelText: 'First Name', // Label displayed above the input field
        prefixIcon: const Icon(Icons.person), // Icon representing user
        hintText: 'Enter first name', // Placeholder text inside the field
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)), // Rounded border for styling
        labelStyle: const TextStyle(fontWeight: FontWeight.w900), // Bold label text
        hintStyle: const TextStyle(fontWeight: FontWeight.w900), // Bold hint text
      ),

      // Validator function to ensure input is not empty
      validator: (value) {
        if (value == null || value.isEmpty) return 'First name is required'; // Displays error message if empty
        return null; // Returns null if the input is valid (no errors)
      },
    );
  }
}