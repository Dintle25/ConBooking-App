/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Password form field
 */


// Import Flutter's material library for UI components
import 'package:flutter/material.dart';

// Defines a reusable password input field for forms
class PasswordFormField extends StatelessWidget {
  final TextEditingController controller; // Controller to manage password input

  // Constructor requires a controller for handling user input
  const PasswordFormField({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller, // Connects input field to the provided controller
      obscureText: true, // Hides password for security

      // Defines the visual design of the input field
      decoration: InputDecoration(
        labelText: 'Password', // Label displayed above the field
        prefixIcon: const Icon(Icons.lock), // Adds a lock icon next to the input box
        hintText: 'Enter password', // Hint text inside the input field
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)), // Sets rounded border
        labelStyle: const TextStyle(fontWeight: FontWeight.w900), // Styles the label text
        hintStyle: const TextStyle(fontWeight: FontWeight.w900), // Styles the hint text
      ),

      // Validator ensures password follows security requirements
      validator: (value) {
        if (value == null || value.isEmpty) return 'Password is required'; // Checks if field is empty
        if (value.length < 8) return 'Minimum 8 characters'; // Ensures password length is at least 8 characters
        if (!value.contains('@')) return 'Must contain @ symbol'; // Requires an "@" symbol for added complexity
        return null; // Returns null if input is valid
      },
    );
  }
}
