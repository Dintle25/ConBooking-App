/*
Student Numbers : 222003812   ,   222052986            ,   220046661  ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Admin Login and Register Page


 */


import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../routes/app_router.dart';

class AdminAuthPage extends StatefulWidget {
  final bool isLogin; // Determines whether the page is for login or registration
  const AdminAuthPage({super.key, required this.isLogin});

  @override
  State<AdminAuthPage> createState() => _AdminAuthPageState();
}

class _AdminAuthPageState extends State<AdminAuthPage> {
  final _formKey = GlobalKey<FormState>(); // Key to manage form validation
  final _emailController = TextEditingController(); // Controller for email input
  final _passwordController = TextEditingController(); // Controller for password input
  final _nameController = TextEditingController(); // Controller for name input (used in registration)
  
  bool _isLoading = false; // Loading state to show a spinner when submitting
  bool _rememberMe = false; // Flag to remember email for future logins
  String _errorMessage = ''; // Holds any error messages during authentication

  @override
  void initState() {
    super.initState();
    _loadRememberedUser(); // Load saved email if "Remember Me" was checked before
  }

  // Load remembered email if it was saved
  void _loadRememberedUser() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? rememberedEmail = prefs.getString('admin_remembered_email');
    if (rememberedEmail != null) {
      setState(() {
        _emailController.text = rememberedEmail;
        _rememberMe = true;
      });
    }
  }

  // Handles login or registration
  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return; // Stop if validation fails
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final auth = FirebaseAuth.instance;
      UserCredential userCredential;

      if (widget.isLogin) {
        // Logging in
        userCredential = await auth.signInWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );

        // Check if the logged-in user is an admin
        final isAdmin = await FirebaseFirestore.instance
            .collection('admins')
            .doc(userCredential.user!.uid)
            .get();

        if (!isAdmin.exists) {
          throw FirebaseAuthException(
            code: 'not-admin',
            message: 'You are not registered as an admin.',
          );
        }

        // Save email if "Remember Me" was checked
        if (_rememberMe) {
          SharedPreferences prefs = await SharedPreferences.getInstance();
          await prefs.setString('admin_remembered_email', _emailController.text.trim());
        }

        // Navigate to admin page
        Navigator.pushReplacementNamed(context, RouteManager.adminPage);
      } else {
        // Registering a new admin
        userCredential = await auth.createUserWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );

        // Store admin details in Firestore
        await FirebaseFirestore.instance.collection('admins').doc(userCredential.user!.uid).set({
          'email': _emailController.text.trim(),
          'name': _nameController.text.trim(),
          'createdAt': Timestamp.now(),
        });

        // Redirect to login page after registration
        Navigator.pushReplacement(
          context, 
          MaterialPageRoute(builder: (_) => const AdminAuthPage(isLogin: true))
        );
      }
    } on FirebaseAuthException catch (e) {
      setState(() {
        _errorMessage = e.message ?? 'Authentication failed';
      });
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // 🔹 Sends a password reset email
  Future<void> _resetPassword() async {
    if (_emailController.text.isEmpty) {
      setState(() {
        _errorMessage = "Please enter your email to reset your password";
      });
      return;
    }

    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: _emailController.text.trim());
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Password reset email sent! Check your inbox.")),
      );
    } catch (e) {
      setState(() {
        _errorMessage = "Failed to send reset email";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(
          widget.isLogin ? 'Admin Login' : 'Admin Register',
          style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        actions: [
          // Button to go back to the main page
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, RouteManager.loginPage);
            },
            child: const Text("Back To Main", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Displays error messages, if any
              if (_errorMessage.isNotEmpty)
                Text(_errorMessage, style: const TextStyle(color: Colors.red)),

              // Name input field (only shown during registration)
              if (!widget.isLogin) ...[
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: 'Full Name',
                    hintText: 'Enter full name',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                  ),
                  validator: (value) => value == null || value.isEmpty ? 'Required' : null,
                ),
                const SizedBox(height: 16),
              ],

              // Email input field
              TextFormField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  hintText: 'Enter email',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                ),
                validator: (value) => value == null || value.isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 16),

              // Password input field
              TextFormField(
                controller: _passwordController,
                decoration: InputDecoration(
                  labelText: 'Password',
                  hintText: 'Enter password',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                ),
                obscureText: true,
                validator: (value) => value == null || value.length < 6 ? 'Minimum 6 characters' : null,
              ),
              const SizedBox(height: 16),

              // "Remember Me" option (only for login)
              if (widget.isLogin)
                Row(
                  children: [
                    Checkbox(
                      value: _rememberMe,
                      onChanged: (value) {
                        setState(() {
                          _rememberMe = value!;
                        });
                      },
                    ),
                    const Text('Remember Me'),
                  ],
                ),
              const SizedBox(height: 24),

              // Submit button (Login or Register)
              ElevatedButton(
                onPressed: _isLoading ? null : _submit,
                child: _isLoading
                    ? const CircularProgressIndicator()
                    : Text(
                        widget.isLogin ? 'Login' : 'Register',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
              ),

              // Forgot Password Button (only for login)
              if (widget.isLogin)
                TextButton(
                  onPressed: _resetPassword,
                  child: const Text("Forgot Password?", style: TextStyle(color: Colors.blue)),
                ),

              // Switch between login and registration
              TextButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AdminAuthPage(isLogin: !widget.isLogin),
                    ),
                  );
                },
                child: Text(
                  widget.isLogin ? 'Don\'t have an account? Register' : 'Already have an account? Login',
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
