/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Course form field
 */

// Import Flutter's material library for UI components
import 'package:flutter/material.dart';

// Defines a reusable form field for entering a course name
class CourseFormField extends StatelessWidget {
  final TextEditingController controller; // Controller to manage text input

  // Constructor that requires a controller to handle text entry
  const CourseFormField({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller, // Connects input field to the provided controller

      // Adds a label and an icon for visual appeal
      decoration: const InputDecoration(
        labelText: 'Course', // Label displayed inside the field
        prefixIcon: Icon(Icons.school), // Icon representing education
      ),

      // Validator to ensure the course name is entered
      validator: (value) {
        if (value == null || value.isEmpty) return 'Course is required'; // Displays error message if empty
        return null; // Returns null if the input is valid (no errors)
      },
    );
  }
}
