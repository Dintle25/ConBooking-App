/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Surname form field
 */


// Import Flutter's material library for UI components
import 'package:flutter/material.dart';

// Defines a reusable form field for entering a surname
class SurnameFormField extends StatelessWidget {
  final TextEditingController controller; // Controller to manage surname input

  // Constructor requires a controller for handling user input
  const SurnameFormField({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller, // Connects input field to the provided controller

      // Defines the visual design of the input field
      decoration: InputDecoration(
        labelText: 'Surname', // Label displayed above the input field
        prefixIcon: const Icon(Icons.person_outline), // Adds an icon representing user profile
        hintText: 'Enter last name', // Placeholder text inside the field
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)), // Sets rounded border
        labelStyle: const TextStyle(fontWeight: FontWeight.w900), // Styles the label text
        hintStyle: const TextStyle(fontWeight: FontWeight.w900), // Styles the hint text
      ),

      // Validator ensures surname is entered
      validator: (value) {
        if (value == null || value.isEmpty) return 'Surname is required'; // Ensures field is not empty
        return null; // Returns null if input is valid
      },
    );
  }
}