/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Student ID form field
 */


// Import Flutter's material library for UI components
import 'package:flutter/material.dart';

// Defines a reusable form field for entering a student number
class StudentIdFormfield extends StatelessWidget {
  final TextEditingController controller; // Controller to manage student number input

  // Constructor requires a controller for handling user input
  const StudentIdFormfield({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller, // Connects input field to the provided controller
      keyboardType: TextInputType.phone, // Sets the keyboard type to numerical input

      // Defines the visual design of the input field
      decoration: InputDecoration(
        labelText: 'Student Number', // Label displayed above the input field
        prefixIcon: const Icon(Icons.person), // Adds a person icon next to the input box
        hintText: 'Enter student number', // Placeholder text inside the field
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)), // Sets rounded border
        labelStyle: const TextStyle(fontWeight: FontWeight.w900), // Styles the label text
        hintStyle: const TextStyle(fontWeight: FontWeight.w900), // Styles the hint text
      ),

      // Validator ensures the student number follows correct format
      validator: (value) {
        if (value == null || value.isEmpty) return 'Student Number is required'; // Ensures field is not empty
        if (!RegExp(r'^\d{9}$').hasMatch(value)) return 'Enter a valid 9-digit student number'; // Ensures exactly 9 digits
        return null; // Returns null if input is valid
      },
    );
  }
}
