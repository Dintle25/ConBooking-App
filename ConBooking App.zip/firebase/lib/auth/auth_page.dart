/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Student Login and Register Page
 */

// Import necessary packages for authentication, UI components, and services
import 'package:firebase/auth/firstName_formfield.dart';
import 'package:firebase/auth/phoneNumber_formfield.dart';
import 'package:firebase/auth/student_id_formfield.dart';
import 'package:firebase/auth/surname_formfield.dart';
import 'package:firebase/routes/app_router.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/auth_service.dart';
import 'email_formfield.dart';
import 'password_formfield.dart';
import 'package:firebase_auth/firebase_auth.dart';

// Stateful Widget for Authentication (Login/Register)
class AuthPage extends StatefulWidget {
  final bool isLogin; // Determines whether to show login or registration
  const AuthPage({super.key, required this.isLogin});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

// State for AuthPage
class _AuthPageState extends State<AuthPage> {
  // Form key to manage form validation
  final _formKey = GlobalKey<FormState>();

  // Controllers for user inputs
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _firstNameController = TextEditingController();
  final _surnameController = TextEditingController();
  final _phoneNumberController = TextEditingController();
  final _studentIdController = TextEditingController();

  // Flags for loading and "Remember Me" functionality
  bool _isLoading = false; // Shows loading state when processing authentication
  bool _rememberMe = false; // Tracks whether user wants to remember email for future logins

  @override
  void initState() {
    super.initState();
    _loadRememberedUser(); // Load stored email if "Remember Me" was checked
  }

  // Load stored email for login if "Remember Me" was previously selected
  void _loadRememberedUser() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? rememberedEmail = prefs.getString('remembered_email');
    if (rememberedEmail != null) {
      setState(() {
        _emailController.text = rememberedEmail; // Auto-fill email field
        _rememberMe = true; // Set "Remember Me" checkbox to checked
      });
    }
  }

  // Handles login or registration
  Future<void> _submit(BuildContext context) async {
    if (!_formKey.currentState!.validate()) return; // Stop if validation fails

    setState(() => _isLoading = true); // Show loading indicator

    try {
      final authService = Provider.of<AuthService>(context, listen: false);

      if (widget.isLogin) {
        // User is logging in
        await authService.login(
          _emailController.text.trim(),
          _passwordController.text.trim(),
        );

        // Save email if "Remember Me" is checked
        if (_rememberMe) {
          SharedPreferences prefs = await SharedPreferences.getInstance();
          await prefs.setString('remembered_email', _emailController.text.trim());
        }

        // Navigate to main page after login
        Navigator.pushReplacementNamed(context, RouteManager.mainPage,
            arguments: _emailController.text.trim());
      } else {
        // User is registering
        await authService.register(
          _emailController.text.trim(),
          _passwordController.text.trim(),
          _firstNameController.text.trim(),
          _surnameController.text.trim(),
          _phoneNumberController.text.trim(),
          _studentIdController.text.trim(),
        );

        // Navigate to login page after successful registration
        Navigator.pushReplacementNamed(context, RouteManager.loginPage);
      }
    } catch (e) {
      // Show error message as a notification
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      setState(() => _isLoading = false); // Hide loading indicator after completion
    }
  }

  // Handles password reset request
  Future<void> _resetPassword() async {
    if (_emailController.text.isEmpty) {
      // Show notification if no email is provided
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter your email to reset password')),
      );
      return;
    }

    try {
      // Send password reset email
      await FirebaseAuth.instance.sendPasswordResetEmail(email: _emailController.text.trim());
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Password reset link sent to ${_emailController.text}')),
      );
    } catch (e) {
      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // Removes default back button
        title: Text(
          widget.isLogin ? 'Student Login' : 'Student Register', // Dynamic title for login/register
          style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)), // Rounded bottom corners
        ),
      ),
      
      // Floating action button for admin login option
      floatingActionButton: TextButton(
        onPressed: () async {
          Navigator.pushReplacementNamed(context, '/adminLogin');
        },
        child: const Text(
          'Login as Admin',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey, // Assign the form key for validation
          child: Column(
            children: [
              // Show additional fields if registering a new student
              if (!widget.isLogin) FirstNameFormField(controller: _firstNameController),
              const SizedBox(height: 13),
              if (!widget.isLogin) SurnameFormField(controller: _surnameController),
              const SizedBox(height: 13),
              if (!widget.isLogin) PhoneFormField(controller: _phoneNumberController),
              const SizedBox(height: 13),
              
              // Email input field (always required)
              EmailFormField(controller: _emailController),
              const SizedBox(height: 13),

              if (!widget.isLogin) StudentIdFormfield(controller: _studentIdController),
              const SizedBox(height: 13),

              // Password input field
              PasswordFormField(controller: _passwordController),
              const SizedBox(height: 13),

              // "Remember Me" option (only for login)
              if (widget.isLogin)
                Row(
                  children: [
                    Checkbox(
                      value: _rememberMe,
                      onChanged: (value) {
                        setState(() {
                          _rememberMe = value!;
                        });
                      },
                    ),
                    const Text('Remember Me'),
                  ],
                ),
              const SizedBox(height: 10),

              // Submit button (login or register)
              ElevatedButton(
                onPressed: _isLoading ? null : () async {
                  await _submit(context); // Call submit function
                },
                child: _isLoading
                    ? const CircularProgressIndicator() // Show loading indicator
                    : Text(
                        widget.isLogin ? 'Login' : 'Register',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
              ),

              // Reset Password Button (only for login)
              if (widget.isLogin)
                TextButton(
                  onPressed: _resetPassword, // Call password reset function
                  child: const Text(
                    'Forgot Password?',
                    style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blue),
                  ),
                ),

              // Switch between login and registration
              TextButton(
                onPressed: () => Navigator.pushReplacementNamed(
                  context,
                  widget.isLogin ? RouteManager.registrationPage : RouteManager.loginPage,
                ),
                child: Text(
                  widget.isLogin ? 'Create an account' : 'Already have an account?',
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}