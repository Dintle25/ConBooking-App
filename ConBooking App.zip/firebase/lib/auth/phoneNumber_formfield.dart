/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Phone number form field
 */


// Import Flutter's material library for UI components
import 'package:flutter/material.dart';

// Defines a reusable phone number input field for forms
class PhoneFormField extends StatelessWidget {
  final TextEditingController controller; // Controller to manage phone number input

  // Constructor requires a controller for handling user input
  const PhoneFormField({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller, // Connects input field to the provided controller
      keyboardType: TextInputType.phone, // Sets the keyboard type to phone number format

      // Defines the visual design of the input field
      decoration: InputDecoration(
        labelText: 'Phone Number', // Label displayed above the input field
        prefixIcon: const Icon(Icons.phone), // Adds a phone icon next to the input box
        hintText: 'Enter phone number', // Hint text inside the input field
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)), // Sets rounded border
        labelStyle: const TextStyle(fontWeight: FontWeight.w900), // Styles the label text
        hintStyle: const TextStyle(fontWeight: FontWeight.w900), // Styles the hint text
      ),

      // Validator ensures phone number follows correct format
      validator: (value) {
        if (value == null || value.isEmpty) return 'Phone number is required'; // Checks if field is empty
        if (!RegExp(r'^\d{10}$').hasMatch(value)) return 'Enter a valid 10-digit number'; // Ensures number is 10 digits
        return null; // Returns null if input is valid
      },
    );
  }
}
