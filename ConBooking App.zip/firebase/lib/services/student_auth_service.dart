// import 'dart:math';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import '../models/student.dart';

// class StudentAuthService extends ChangeNotifier {
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;

//   // Firestore collection reference
//   CollectionReference get _studentsCollection => _firestore.collection('students');

//   // Add a new student
//   Future<void> addStudent({
//     required String firstName,
//     required String surname,
//     required String phoneNumber,
//     required String course,
//   }) async {
//     final studentNo = (Random().nextInt(900000) + 100000).toString();

//     final student = Student(
//       studentNo: studentNo,
//       firstName: firstName,
//       surname: surname,
//       phoneNumber: phoneNumber,
//       course: course,
//     );

//     try {
//       await _studentsCollection.doc(studentNo).set(student.toFirestore());
//     } catch (e) {
//       throw Exception('Failed to register student: $e');
//     }

//     notifyListeners();
//   }

//   // Fetch student data
//   Future<Student?> getStudentData(String studentNo) async {
//     final doc = await _studentsCollection.doc(studentNo).get();
//     if (doc.exists) {
//       return Student.fromFirestore(doc);
//     }
//     return null;
//   }

//   // Update student data
//   Future<void> updateStudent(String studentNo, Student updatedStudent) async {
//     await _studentsCollection.doc(studentNo).update(updatedStudent.toFirestore());
//     notifyListeners();
//   }

//   // Delete student
//   Future<void> deleteStudent(String studentNo) async {
//     await _studentsCollection.doc(studentNo).delete();
//     notifyListeners();
//   }

//   // Realtime fetch of all students
//   Stream<List<Student>> getStudents() {
//     return _studentsCollection
//         .orderBy('firstName')
//         .snapshots()
//         .map((snapshot) =>
//             snapshot.docs.map((doc) => Student.fromFirestore(doc)).toList());
//   }
// }
