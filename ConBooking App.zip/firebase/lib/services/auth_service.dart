import 'package:firebase/models/consultation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/student.dart';

class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance; // Firebase Auth instance
  final FirebaseFirestore _firestore = FirebaseFirestore.instance; // Firestore instance

  // Getter to access the currently authenticated user
  User? get currentUser => _auth.currentUser;

  // Method to log in a student with email and password
  Future<User?> login(String email, String password) async {
    try {
      final userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return userCredential.user;
    } on FirebaseAuthException catch (e) {
      throw _authError(e.code);
    }
  }

//   import 'dart:math';
// import '../models/student.dart';

Future<User?> register(String email, String password, String firstName, String surname, String phone, String studentId) async {
  try {
    // Step 1: Register the user
    final userCredential = await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );

    final uid = userCredential.user!.uid;
    final studentNo = _generateStudentNumber();

    // Step 2: Save student profile to Firestore
    await _firestore.collection('students').doc(uid).set({
      'firstName': firstName,
      'surname': surname,
      'phoneNumber': phone,
      'studentId': studentId,
      'studentNo': studentNo,
      'userId': uid,
      'createdAt': DateTime.now(),
    });

    return userCredential.user;

  } on FirebaseAuthException catch (e) {
    throw _authError(e.code);
  }
}




  // Handle FirebaseAuth errors
  String _authError(String code) {
    switch (code) {
      case 'invalid-email':
        return 'Invalid email address';
      case 'weak-password':
        return 'Password must be 6+ characters';
      default:
        return 'Authentication failed';
    }
  }

  // Fetch a student's profile from Firestore
 Future<Student?> getStudentData(String uid) async {
  final doc = await FirebaseFirestore.instance.collection('students').doc(uid).get();
  if (doc.exists) {
    return Student.fromFirestore(doc);
  }
  return null;
}



  // 🔄 Realtime list of all students
  Stream<List<Student>> getStudents() {
    return _firestore
        .collection('students')
        .orderBy('firstName')
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => Student.fromFirestore(doc)).toList());
  }

  Future<void> addStudent(String firstName, String surname, String phone, String studentId) async {
  if (currentUser == null) throw Exception('User not authenticated');

  String studentNo = _generateStudentNumber(); // random generator
  await _firestore.collection('students').add({
    'firstName': firstName,
    'surname': surname,
    'phone': phone,
    'studentId': studentId,
    'studentNo': studentNo,
    'userId': currentUser!.uid,
    'createdAt': DateTime.now(),
  });
// await FirebaseFirestore.instance
//     .collection('students')
//     .doc(userCredential.user!.uid)
//     .set({
//   'firstName': firstName,
//   'surname': surname,
//   'studentNo': studentNo, // or generate one
//   'phoneNumber': phone,
// });

  notifyListeners();
}

String _generateStudentNumber() {
  final now = DateTime.now();
  final rand = now.microsecondsSinceEpoch % 10000;
  return 'STU${now.year}${rand.toString().padLeft(4, '0')}';
}


  // ✏️ Update a student's profile
  // Future<void> updateStudent(String docId, Student updatedStudent) async {
  //   await _firestore.collection('students').doc(docId).update(updatedStudent.toFirestore());
  //   notifyListeners();
  // }

// 'firstName': firstName,
//     'surname': surname,
//     'phone': phone,
//     'studentId': studentId,
//     'studentNo': studentNo,
//     'userId': currentUser!.uid,
//     'createdAt': DateTime.now(),

  Future<void> updateStudent(String docId, String studentId,String firstName, String surname,String phoneNumber
) async {
  await _firestore
      .collection('students')
      .doc(docId)
      .update({'studentId': studentId,'firstName': firstName, 'surname': surname,'phoneNumber': phoneNumber,
      });
  notifyListeners();
}

  // 🗑️ Delete a student
  Future<void> deleteStudent(String docId) async {
    await _firestore.collection('students').doc(docId).delete();
    notifyListeners();
  }

  // 🔍 Fetch single student by document ID
  Future<Student?> getStudentById(String docId) async {
    final doc = await _firestore.collection('students').doc(docId).get();
    if (doc.exists) {
      return Student.fromFirestore(doc);
    }
    return null;
  }  // ... your existing code ...

  // 🔄 Realtime list of consultations for current user
  Stream<List<Consultation>> getConsultations() {
  if (currentUser == null) {
    return const Stream.empty();
  }

  return _firestore
      .collection('consultations')
      .where('studId', isEqualTo: currentUser!.uid)
      .snapshots()
      .map((snapshot) =>
          snapshot.docs.map((doc) => Consultation.fromFirestore(doc)).toList());
}


  // ➕ Add new consultation
 Future<void> addConsultation({
  required String date,
  required String time,
  required String description,
  required String topic,
  required String lecture,
}) async {
  if (currentUser == null) throw Exception('User not authenticated');

  try {
    // 🔍 Fetch the student's record using the current UID
    final studentDoc = await _firestore.collection('students').doc(currentUser!.uid).get();

    if (!studentDoc.exists) throw Exception('Student profile not found');

    final studentId = studentDoc.data()!['studentId']; // get studentId field from Firestore

    // ✅ Now add the consultation
    await _firestore.collection('consultations').add({
      'date': date,
      'time': time,
      'description': description,
      'topic': topic,
      'lecture': lecture,
      'studId': currentUser!.uid,        // UID, for auth checks
      'studentId': studentId,            // Custom student ID, visible in UI
      'status': true,                    // boolean status
      'createdAt': FieldValue.serverTimestamp(),
    });

    notifyListeners();
  } catch (e) {
    throw Exception('Failed to add consultation: $e');
  }
}



  // ✏️ Update consultation by document ID
  // Future<void> updateConsultation(String docId, Consultation updated) async {
  //   await _firestore
  //       .collection('consultations')
  //       .doc(docId)
  //       .update(updated.toFirestore());

  //   notifyListeners();
  // }
    Future<void> updateConsultation(String docId, String lecture,String date, String time,String topic,String description
) async {
  await _firestore
      .collection('consultations')
      .doc(docId)
      .update({'lecture': lecture,'date': date, 'time': time,'topic': topic,'description': description,
      });

  notifyListeners();
}

  // 🗑️ Delete consultation
  Future<void> deleteConsultation(String consultationId) async {
    await _firestore.collection('consultations').doc(consultationId).delete();
    notifyListeners();
  }

  // 🔍 Fetch a single consultation by ID
  Future<Consultation?> getConsultationById(String docId) async {
    final doc = await _firestore.collection('consultations').doc(docId).get();
    if (doc.exists) {
      return Consultation.fromFirestore(doc);
    }
    return null;
  }
}
