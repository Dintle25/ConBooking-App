/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Consultation Model
 */

// Import required packages for Firestore database access and date formatting
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

// Defines a model class for Consultation sessions
class Consultation {
  final String date; // Stores consultation date
  final String time; // Stores consultation time
  final String description; // Brief description of the consultation
  final String topic; // Topic being discussed in the consultation
  final String studId; // Student's unique ID
  final String lecture; // Name or ID of the lecturer
  final String studentId; // Additional student identifier
  String id; // Unique identifier for each consultation document
  final bool status; // Tracks whether the consultation is active (default: true)

  // Constructor to initialize a Consultation instance with required data
  Consultation({
    required this.id,
    required this.date,
    required this.time,
    required this.description,
    required this.topic,
    required this.studId,
    required this.lecture,
    this.status = true, // Default consultation status is active
    this.studentId = '', // Default studentId is an empty string
  });

  // Factory constructor to create a Consultation object from Firestore document snapshot
  factory Consultation.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>; // Retrieve data from Firestore document

    // Extract and format date and time values
    final dateValue = data['date'];
    final timeValue = data['time'];

    return Consultation(
      id: doc.id, // Assign Firestore document ID
      date: dateValue is Timestamp
          ? DateFormat('yyyy-MM-dd').format(dateValue.toDate()) // Convert Timestamp to readable date format
          : (dateValue ?? ''), // If date is null, assign an empty string
      time: timeValue is Timestamp
          ? DateFormat('HH:mm').format(timeValue.toDate()) // Convert Timestamp to readable time format
          : (timeValue ?? ''), // If time is null, assign an empty string
      description: data['description'] ?? '', // Retrieve description or assign empty string if null
      topic: data['topic'] ?? '', // Retrieve topic or assign empty string if null
      lecture: data['lecture'] ?? '', // Retrieve lecturer's name or ID
      studId: data['studId'] ?? '', // Retrieve student ID
      status: data['status'] is bool ? data['status'] : false, // Ensure status is a boolean, default to false if missing
      studentId: data['studentId'] ?? '', // Retrieve student ID or empty string if null
    );
  }

  // Converts Consultation object to a Firestore-compatible map
  Map<String, dynamic> toFirestore() {
    return {
      'date': date, // Stores date as a string
      'time': time, // Stores time as a string
      'description': description, // Stores consultation description
      'topic': topic, // Stores consultation topic
      'studId': studId, // Stores student ID
      'lecture': lecture, // Stores lecturer information
      'status': status, // Stores consultation status
      'studentId': studentId, // Stores student ID
    };
  }
}