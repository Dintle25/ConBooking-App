/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Login Model
 */


// Defines a simple model class for login credentials
class Login {
  String email; // Stores user email
  String password; // Stores user password

  // Constructor that requires email and password values for initialization
  Login({required this.email, required this.password});
}