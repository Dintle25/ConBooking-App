/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Student Model
 */
// Import Firestore package to interact with the Firebase database
import 'package:cloud_firestore/cloud_firestore.dart';

/// Represents a student in the application.
class Student {
  final String studentNo;     // Unique student number
  final String firstName;     // Student's first name
  final String surname;       // Student's surname
  final String phoneNumber;   // Student's phone number
  final String studentId;     // Student's course or unique identifier

  // Constructor to initialize a Student object
  Student({
    required this.studentNo, // Requires student number
    required this.firstName, // Requires first name
    required this.surname, // Requires surname
    required this.phoneNumber, // Requires phone number
    required this.studentId, // Requires student course/identifier
  });

  // Factory method to create a Student object from Firestore document data
  factory Student.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>; // Extracts data from Firestore document
    
    return Student(
      studentNo: data['studentNo'] ?? '', // Retrieves student number or defaults to an empty string
      firstName: data['firstName'] ?? '', // Retrieves first name or defaults to an empty string
      surname: data['surname'] ?? '', // Retrieves surname or defaults to an empty string
      phoneNumber: data['phoneNumber'] ?? '', // Retrieves phone number or defaults to an empty string
      studentId: data['studentId'] ?? '', // Retrieves student course/identifier or defaults to an empty string
    );
  }

  // Converts Student object into a format compatible with Firestore storage
  Map<String, dynamic> toFirestore() {
    return {
      'studentNo': studentNo, // Stores student number
      'firstName': firstName, // Stores first name
      'surname': surname, // Stores surname
      'phoneNumber': phoneNumber, // Stores phone number
      'studentId': studentId, // Stores student course/identifier
    };
  }
}
