/*
Student Numbers : 222003812   , 222052986              , 220046661    ,  222026610
Student Names   : Dintle Mili , Rethabile Erick Siase  , Modise Qhala ,  Morena Motsoeneng
Question        : Profile data Model
 */

// Import Dart's IO library to handle file operations
import 'dart:io';
// Defines a model class for storing profile screen data
class ProfileData {
  String name; // Stores the user's name
  String role; // Stores the user's role (e.g., student, admin, lecturer)
  String email; // Stores the user's email address
  String phoneNumber; // Stores the user's phone number
  File? image; // Optional profile image stored as a file

  // Constructor to initialize profile data
  ProfileData({
    required this.name, // Requires the user's name
    required this.role, // Requires the user's role
    required this.email, // Requires the user's email
    required this.phoneNumber, // Requires the user's phone number
    this.image, // Profile image is optional
  });
}
